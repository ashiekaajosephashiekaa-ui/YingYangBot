const { Telegraf, Markup } = require("telegraf");

const BOT_TOKEN = process.env.BOT_TOKEN;

if (!BOT_TOKEN) {
  console.error("Missing BOT_TOKEN environment variable. Add it in Railway Variables.");
  process.exit(1);
}

const bot = new Telegraf(BOT_TOKEN);

const TOKEN_URL = "https://phantom.app/tokens/solana/8q4c4ycdE";
const CONTRACT_ADDRESS = "8q4c4ycdEZMjcYxUgo9SacDLq172tSHSNeRSXY9Mpump";
const WEBSITE_URL = "https://linktr.ee/YingYangGOD";

const mainKeyboard = Markup.inlineKeyboard([
  [Markup.button.url("☯️ Community Chat 1", "https://t.me/+_61PBUqa6JQ1OTg9")],
  [Markup.button.url("☯️ Community Chat 2", "https://t.me/+BG5_pIkPOANkZDU1")],
  [Markup.button.url("📢 Official Telegram Channel", "https://t.me/YingYangGOD")],
  [Markup.button.url("🪙 Token Information", TOKEN_URL)],
  [Markup.button.url("🌐 Official Website", WEBSITE_URL)],
  [Markup.button.callback("📋 Show Contract Address", "show_contract")]
]);

const welcomeMessage = [
  "☯️ *Welcome to YingYangGOD*",
  "",
  "Your community hub for official updates, community links, and token information.",
  "",
  "Use the buttons below to visit our official resources.",
  "",
  "🪙 *Token page:* [View on Phantom](" + TOKEN_URL + ")",
  "📋 *Contract address:*",
  "`" + CONTRACT_ADDRESS + "`",
  "",
  "Please verify token details carefully before making any transaction. This bot does not provide financial advice."
].join("\n");

bot.start(async (ctx) => {
  await ctx.reply(welcomeMessage, {
    parse_mode: "Markdown",
    ...mainKeyboard
  });
});

bot.command("community", async (ctx) => {
  await ctx.reply("☯️ *YingYangGOD Community Links*\n\nChoose a group or visit the official channel:", {
    parse_mode: "Markdown",
    ...Markup.inlineKeyboard([
      [Markup.button.url("☯️ Community Chat 1", "https://t.me/+_61PBUqa6JQ1OTg9")],
      [Markup.button.url("☯️ Community Chat 2", "https://t.me/+BG5_pIkPOANkZDU1")],
      [Markup.button.url("📢 Official Telegram Channel", "https://t.me/YingYangGOD")]
    ])
  });
});

bot.command("token", async (ctx) => {
  await ctx.reply(
    "🪙 *YingYangGOD Token Information*\n\n" +
    "Token page: " + TOKEN_URL + "\n\n" +
    "Contract address:\n`" + CONTRACT_ADDRESS + "`\n\n" +
    "Always verify the address before interacting with a token.",
    {
      parse_mode: "Markdown",
      ...Markup.inlineKeyboard([
        [Markup.button.url("🪙 View Token on Phantom", TOKEN_URL)],
        [Markup.button.callback("📋 Show Contract Address", "show_contract")]
      ])
    }
  );
});

bot.command("website", async (ctx) => {
  await ctx.reply("🌐 Visit the official YingYangGOD links page:", {
    ...Markup.inlineKeyboard([
      [Markup.button.url("Open Official Website", WEBSITE_URL)]
    ])
  });
});

bot.command("help", async (ctx) => {
  await ctx.reply(
    "Available commands:\n" +
    "/start — Open the main menu\n" +
    "/community — View community links\n" +
    "/token — View token information\n" +
    "/website — Open the official links page\n" +
    "/help — Show this help message"
  );
});

bot.action("show_contract", async (ctx) => {
  await ctx.answerCbQuery("Contract address");
  await ctx.reply(
    "📋 *YingYangGOD Contract Address*\n\n`" + CONTRACT_ADDRESS + "`\n\nTap and hold the address to copy it.",
    { parse_mode: "Markdown" }
  );
});

bot.catch((error, ctx) => {
  console.error(`Bot error while handling ${ctx.updateType}:`, error);
});

bot.launch().then(() => {
  console.log("YingYangGOD Telegram bot is running.");
}).catch((error) => {
  console.error("Failed to launch bot:", error);
  process.exit(1);
});

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
