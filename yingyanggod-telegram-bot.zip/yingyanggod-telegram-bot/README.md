# YingYangGOD Telegram Bot

A simple Telegram bot with community links, official channel, token page, website, and contract-address display.

## Files
- `index.js` — bot logic
- `package.json` — Node.js dependencies and start command

## Deploy with GitHub and Railway

1. Create a Telegram bot using **@BotFather** and copy its token.
2. Create a GitHub repository and upload these files.
3. In Railway, create a new project and deploy from your GitHub repository.
4. In the Railway service's **Variables** section, add:
   - `BOT_TOKEN` = your Telegram bot token
5. Railway will install dependencies and run `npm start` using `package.json`.
6. Check the deployment logs. You should see: `YingYangGOD Telegram bot is running.`

Keep `BOT_TOKEN` private. Do not commit it to GitHub or paste it into public messages.

## BotFather description

Use `/setdescription` with @BotFather and select your bot. Suggested description:

Welcome to the official YingYangGOD☯️ community hub. Find community links, official updates, and token information. Token page: https://phantom.app/tokens/solana/8q4c4ycdE CA: 8q4c4ycdEZMjcYxUgo9SacDLq172tSHSNeRSXY9Mpump

Use `/setabouttext` to set the short profile text:

YingYangGOD ☯️ | Official community, updates, website, and token information.

## Commands
- `/start` — Main menu
- `/community` — Community groups and channel
- `/token` — Token page and contract address
- `/website` — Official website
- `/help` — Help

## Note
The bot uses long polling, which works for a straightforward Railway deployment. Keep only one active deployment instance for this bot token. Neutral wording does not guarantee Telegram Ads approval; follow the current Telegram Ads rules.
